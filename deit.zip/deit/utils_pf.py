import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import datasets, transforms
from torch.utils.data.sampler import SubsetRandomSampler
import numpy as np
from os import path
import os
import matplotlib.pyplot as plt
import seaborn as sns
from torchvision import transforms
from PIL import Image, ImageDraw
import time


mu = [0.485, 0.456, 0.406]
std = [0.229, 0.224, 0.225]


def clamp(X, lower_limit, upper_limit):
    return torch.max(torch.min(X, upper_limit), lower_limit)


def get_loaders(args):
    args.mu = mu
    args.std = std
    valdir = path.join(args.data_dir, 'val')
    val_dataset = datasets.ImageFolder(valdir,
                                       transforms.Compose([transforms.Resize(args.img_size),
                                                           transforms.CenterCrop(args.crop_size),
                                                           transforms.ToTensor(),
                                                           transforms.Normalize(mean=args.mu, std=args.std)
                                                           ]))
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=args.batch_size, shuffle=True,
                                             num_workers=args.workers, pin_memory=True)
    return val_loader

def conver2pic(perterb_x,i,j):
    img=perterb_x
    invTrans=transforms.Compose([transforms.Normalize(mean=[0.,0.,0.],std=[1/0.229,1/0.224,1/0.225]),
                            transforms.Normalize(mean=[-0.485, -0.456, -0.406],std=[1.,1.,1.])])
    img=invTrans(img)
    '''
    img = perterb_x.cpu().numpy().transpose(1,2,0)
    stdt=np.array(std)
    mut=np.array(std)
    img = (img * stdt + mut) * 255
    '''
    
    toPIL = transforms.ToPILImage()
    pic = toPIL(img)
    return pic
    #pic.save('D:/ViT/Patch-Fool-main/Patch-Fool-main/output/perb_pic_{}_{}.png'.format(i,j))

def get_dimension(lst):
    if isinstance(lst,list):
        lst1=lst[0]
        return[len(lst)] + get_dimension(lst1)
    else:
        return[]
    

def visualize_loss(loss_list):
    plt.figure()
    plt.plot(loss_list)
    plt.savefig('output/loss/loss{:.4f}_{}_{}_{}_{}_{}.png'.format(loss_list[-1], args.network, args.attack_learning_rate,
                                                          args.train_attack_iters, args.step_size, args.gamma))
    plt.close()

def visualize_attention_map(atten1, atten2, image1, image2, original_result, after_attack_result, max_patch_index):
    atten1 = [x.mean(dim=1).cpu() for x in atten1]
    atten2 = [x.mean(dim=1).cpu() for x in atten2]
    image1 = image1.cpu()
    image2 = image2.cpu()
    original_result = original_result.cpu()
    after_attack_result = after_attack_result.cpu()

    if image1.size(0) > 4:
        atten1 = [x[:4] for x in atten1]
        atten2 = [x[:4] for x in atten2]
        image1 = image1[:4]
        image2 = image2[:4]
        original_result = original_result[:4]
        after_attack_result = after_attack_result[:4]                   
    pic_num = image1.size(0)
    if 'LeViT' in args.network:
        patch_num = atten1[0].size(-1)
    else:
        patch_num = atten1[0].size(-1) - 1
    patch_per_line = int(patch_num ** 0.5)
    patch_size = int(image1.size(-1) / patch_per_line)
    to_PIL = transforms.ToPILImage()

    for i in range(pic_num):
        if not path.exists('output/{}'.format(i)):
            os.mkdir('output/{}'.format(i))

        original_img = to_PIL(image1[i].squeeze())
        after_attack_img = to_PIL(image2[i].squeeze())
        original_atten = [x[i] for x in atten1]  # [197x197]
        after_attack_atten = [x[i] for x in atten2]

        with open('output/{}/atten.txt'.format(i), 'w') as f:
            print("Base model result: {}\tAttack model result:{}".format(original_result[i], after_attack_result[i]))
            print("Base model result: {}\tAttack model result:{}".format(original_result[i],
                                                                         after_attack_result[i]), file=f)
            for j in [4]:  # one layer
            # for j in range(len(original_atten)):  # each block
                print("Processing Image:{}\tLayer:{}".format(i, j))
                original_block_layer = original_atten[j]
                after_attack_atten_layer = after_attack_atten[j]
                vmin = min(original_block_layer.min(), after_attack_atten_layer.min())
                vmax = max(original_block_layer.max(), after_attack_atten_layer.max())
                plt.figure(figsize=(70, 30))
                plt.subplot(1, 2, 1)
                plt.title('Original')
                sns.heatmap(original_block_layer.data, annot=False, vmin=vmin, vmax=vmax)
                plt.subplot(1, 2, 2)
                plt.title('Attack patch {}'.format(max_patch_index[i] + 1))
                sns.heatmap(after_attack_atten_layer.data, annot=False, vmin=vmin, vmax=vmax)
                plt.savefig('output/{}/atten_layer{}.png'.format(i, j))
                plt.close()

                original_block_layer = original_block_layer.mean(dim=0)
                after_attack_atten_layer = after_attack_atten_layer.mean(dim=0)
                print('layer_{}'.format(j), file=f)
                print(original_block_layer, file=f)
                print(' ', file=f)
                print(after_attack_atten_layer, file=f)
                print(' ', file=f)
                print(after_attack_atten_layer - original_block_layer, file=f)

                plt.figure()
                plt.subplot(2, 2, 1)
                plt.imshow(original_img)
                plt.subplot(2, 2, 2)
                plt.imshow(after_attack_img)

                if 'DeiT' in args.network:
                    original_block_layer = original_block_layer[1:]
                    after_attack_atten_layer = after_attack_atten_layer[1:]
                plt.subplot(2, 2, 3)
                sns.heatmap(original_block_layer.view(patch_per_line, patch_per_line).data, annot=False)
                plt.subplot(2, 2, 4)
                sns.heatmap(after_attack_atten_layer.view(patch_per_line, patch_per_line).data, annot=False)
                plt.savefig('output/{}/atten_layer{}_img.png'.format(i, j))
                plt.close()





    # filter = torch.ones([1, 3, patch_size, patch_size])
    # atten = F.conv_transpose2d(atten, filter, stride=patch_size)
    # add_atten = torch.mul(atten, image)


'''
@Parameter atten_grad, ce_grad: should be 2D tensor with shape [batch_size, -1]
'''
def PCGrad(atten_grad, ce_grad, sim, shape):
    pcgrad = atten_grad[sim < 0]
    temp_ce_grad = ce_grad[sim < 0]
    dot_prod = torch.mul(pcgrad, temp_ce_grad).sum(dim=-1)
    dot_prod = dot_prod / torch.norm(temp_ce_grad, dim=-1)
    pcgrad = pcgrad - dot_prod.view(-1, 1) * temp_ce_grad
    atten_grad[sim < 0] = pcgrad
    atten_grad = atten_grad.view(shape)
    return atten_grad


'''
random shift several patches within the range
'''
def shift_image(image, range, mu, std, patch_size=16):
    batch_size, channel, h, w = image.shape
    h_range, w_range = range
    new_h = h + 2 * h_range * patch_size
    new_w = w + 2 * w_range * patch_size
    new_image = torch.zeros([batch_size, channel, new_h, new_w]).cuda()
    new_image = (new_image - mu) / std
    shift_h = np.random.randint(-h_range, h_range+1)
    shift_w = np.random.randint(-w_range, w_range+1)
    # shift_h = np.random.randint(-1, 2)
    # shift_w = 0
    new_image[:, :, h_range*patch_size : h+h_range*patch_size, w_range*patch_size : w + w_range*patch_size] = image.detach()
    h_start = (h_range + shift_h) * patch_size
    w_start = (w_range + shift_w) * patch_size
    new_image = new_image[:, :, h_start : h_start+h, w_start : w_start+w]
    return new_image



class my_logger:
    def __init__(self, args):
        name = "{}_{}_{}_{}_{}.log".format(args.name, args.model, args.dataset, args.train_attack_iters,
                                           args.attack_learning_rate)
        args.name = name
        self.name = path.join(args.log_dir, name)
        with open(self.name, 'w') as F:
            print('\n'.join(['%s:%s' % item for item in args.__dict__.items() if item[0][0] != '_']), file=F)
            print('\n', file=F)

    def info(self, content):
        with open(self.name, 'a') as F:
            print(content)
            print(content, file=F)


class my_meter:
    def __init__(self):
        self.meter_list = {}

    def add_loss_acc(self, model_name, loss_dic: dict, correct_num, batch_size):
        if model_name not in self.meter_list.keys():
            self.meter_list[model_name] = self.model_meter()
        sub_meter = self.meter_list[model_name]
        sub_meter.add_loss_acc(loss_dic, correct_num, batch_size)

    def clean_meter(self):
        for key in self.meter_list.keys():
            self.meter_list[key].clean_meter()

    def get_loss_acc_msg(self):
        msg = []
        for key in self.meter_list.keys():
            sub_meter = self.meter_list[key]
            sub_loss_bag = sub_meter.get_loss()
            loss_msg = ["{}: {:.4f}({:.4f})".format(x, sub_meter.last_loss[x], sub_loss_bag[x])
                        for x in sub_loss_bag.keys()]
            loss_msg = " ".join(loss_msg)
            msg.append("model:{} Loss:{} Acc:{:.4f}({:.4f})".format(
                key, loss_msg, sub_meter.last_acc, sub_meter.get_acc()))
        msg = "\n".join(msg)
        return msg

    class model_meter:
        def __init__(self):
            self.loss_bag = {}
            self.acc = 0.
            self.count = 0
            self.last_loss = {}
            self.last_acc = 0.

        def add_loss_acc(self, loss_dic: dict, correct_num, batch_size):
            for loss_name in loss_dic.keys():
                if loss_name not in self.loss_bag.keys():
                    self.loss_bag[loss_name] = 0.
                self.loss_bag[loss_name] += loss_dic[loss_name] * batch_size
            self.last_loss = loss_dic
            self.last_acc = correct_num / batch_size
            self.acc += correct_num
            self.count += batch_size

        def get_loss(self):
            return {x: self.loss_bag[x] / self.count for x in self.loss_bag.keys()}

        def get_acc(self):
            return self.acc / self.count

        def clean_meter(self):
            self.__init__()



'''visualize code'''
def grid_show(to_shows, cols):
    rows = (len(to_shows)-1) // cols + 1
    it = iter(to_shows)
    fig, axs = plt.subplots(rows, cols, figsize=(rows*8.5, cols*2))
    for i in range(rows):
        for j in range(cols):
            try:
                image, title = next(it)
            except StopIteration:
                image = np.zeros_like(to_shows[0][0])
                title = 'pad'
            axs[i, j].imshow(image)
            axs[i, j].set_title(title)
            axs[i, j].set_yticks([])
            axs[i, j].set_xticks([])
    plt.show()

def visualize_head(att_map):
    ax = plt.gca()
    # Plot the heatmap
    im = ax.imshow(att_map)
    # Create colorbar
    cbar = ax.figure.colorbar(im, ax=ax)
    plt.show()
    
def visualize_heads(att_map, cols):
    to_shows = []
    att_map = att_map.squeeze()
    for i in range(att_map.shape[0]):
        to_shows.append((att_map[i], f'Head {i}'))
    average_att_map = att_map.mean(axis=0)
    to_shows.append((average_att_map, 'Head Average'))
    grid_show(to_shows, cols=cols)

def gray2rgb(image):
    return np.repeat(image[...,np.newaxis],3,2)
    
def cls_padding(image, mask, cls_weight, grid_size):
    if not isinstance(grid_size, tuple):
        grid_size = (grid_size, grid_size)
        
    image = np.array(image)

    H, W = image.shape[:2]
    delta_H = int(H/grid_size[0])
    delta_W = int(W/grid_size[1])
    
    padding_w = delta_W
    padding_h = H
    padding = np.ones_like(image) * 255
    padding = padding[:padding_h, :padding_w]
    
    padded_image = np.hstack((padding,image))
    padded_image = Image.fromarray(padded_image)
    draw = ImageDraw.Draw(padded_image)
    draw.text((int(delta_W/4),int(delta_H/4)),'CLS', fill=(0,0,0)) # PIL.Image.size = (W,H) not (H,W)

    mask = mask / max(np.max(mask),cls_weight)
    cls_weight = cls_weight / max(np.max(mask),cls_weight)
    
    if len(padding.shape) == 3:
        padding = padding[:,:,0]
        padding[:,:] = np.min(mask)
    mask_to_pad = np.ones((1,1)) * cls_weight
    mask_to_pad = Image.fromarray(mask_to_pad)
    mask_to_pad = mask_to_pad.resize((delta_W, delta_H))
    mask_to_pad = np.array(mask_to_pad)

    padding[:delta_H,  :delta_W] = mask_to_pad
    padded_mask = np.hstack((padding, mask))
    padded_mask = padded_mask
    
    meta_mask = np.zeros((padded_mask.shape[0], padded_mask.shape[1],4))
    meta_mask[delta_H:,0: delta_W, :] = 1 
    
    return padded_image, padded_mask, meta_mask
    

def visualize_grid_to_grid_with_cls(att_map, grid_index, image, grid_size=14, alpha=0.6):
    if not isinstance(grid_size, tuple):
        grid_size = (grid_size, grid_size)
    
    attention_map = att_map[grid_index]
    cls_weight = attention_map[0]
    
    mask = attention_map[1:].reshape(grid_size[0], grid_size[1])
    mask = Image.fromarray(mask).resize((image.size))
    
    padded_image ,padded_mask, meta_mask = cls_padding(image, mask, cls_weight, grid_size)
    
    if grid_index != 0: # adjust grid_index since we pad our image
        grid_index = grid_index + (grid_index-1) // grid_size[1]
        
    grid_image = highlight_grid(padded_image, [grid_index], (grid_size[0], grid_size[1]+1))
    
    fig, ax = plt.subplots(1, 2, figsize=(10,7))
    fig.tight_layout()
    
    ax[0].imshow(grid_image)
    ax[0].axis('off')
    
    ax[1].imshow(grid_image)
    ax[1].imshow(padded_mask, alpha=alpha, cmap='rainbow')
    ax[1].imshow(meta_mask)
    ax[1].axis('off')
    

def visualize_grid_to_grid(att_map, grid_index, image, grid_size=14, alpha=0.6):
    if not isinstance(grid_size, tuple):
        grid_size = (grid_size, grid_size)
    
    H,W = att_map.shape
    with_cls_token = False
      
    grid_image = highlight_grid(image, [grid_index], grid_size)
    
    mask = att_map[grid_index].reshape(grid_size[0], grid_size[1])
    mask = Image.fromarray(mask).resize((image.size))
    
    fig, ax = plt.subplots(1, 2, figsize=(10,7))
    fig.tight_layout()
    
    ax[0].imshow(grid_image)
    ax[0].axis('off')
    
    ax[1].imshow(grid_image)
    ax[1].imshow(mask/np.max(mask), alpha=alpha, cmap='rainbow')
    ax[1].axis('off')
    plt.show()
    
def highlight_grid(image, grid_indexes, grid_size=14):
    if not isinstance(grid_size, tuple):
        grid_size = (grid_size, grid_size)
    
    W, H = image.size
    h = H / grid_size[0]
    w = W / grid_size[1]
    image = image.copy()
    for grid_index in grid_indexes:
        x, y = np.unravel_index(grid_index, (grid_size[0], grid_size[1]))
        a= ImageDraw.ImageDraw(image)
        a.rectangle([(y*w,x*h),(y*w+w,x*h+h)],fill =None,outline ='red',width =2)
    return image

def random_shift(X):
    seed = int(time.time())
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        
    shift_num_x_tensor = torch.randint(low=-10,high=10,size=())
    shift_num_x_scalar = shift_num_x_tensor.item()
    shift_num_y_tensor = torch.randint(low=-10,high=10,size=())
    shift_num_y_scalar = shift_num_y_tensor.item()
    print("shift_x:",shift_num_x_scalar,"shift_y:",shift_num_y_scalar)
    #shift_num_x_scalar = 1
    #shift_num_y_scalar = 1
    
    batch_size, channels, height, width = X.shape
    translated_tensor = torch.full_like(X,fill_value=0)
    
    x_min, x_max = max(0,-shift_num_x_scalar),min(width,width-shift_num_x_scalar)
    y_min, y_max = max(0,-shift_num_y_scalar),min(height,height-shift_num_y_scalar)
    
    src_x_min,src_x_max = 0 if shift_num_x_scalar >= 0 else -shift_num_x_scalar, width if shift_num_x_scalar <=0 else width-shift_num_x_scalar
    src_y_min,src_y_max = 0 if shift_num_y_scalar >= 0 else -shift_num_y_scalar, width if shift_num_y_scalar <=0 else width-shift_num_y_scalar
    
    translated_tensor[:,:,y_min:y_max,x_min:x_max] = X[:,:,src_y_min:src_y_max,src_x_min:src_x_max]
    
    return translated_tensor