python main.py \
--eval \
--model deit_base_patch16_224 \
--data-path D:/ViT/imagenet \
--svd_type 'mix_head_fc_qk'