# Copyright (c) 2015-present, Facebook, Inc.
# All rights reserved.
import argparse
import datetime
import numpy as np
import time
import torch
import torch.backends.cudnn as cudnn
import json
import torch.nn as nn
import torch.nn.functional as F

from pathlib import Path

from timm.data import Mixup
from timm.models import create_model
from timm.loss import LabelSmoothingCrossEntropy, SoftTargetCrossEntropy
from timm.scheduler import create_scheduler
from timm.optim import create_optimizer
from timm.utils import NativeScaler, get_state_dict, ModelEma

from datasets import build_dataset
from engine import train_one_epoch, evaluate
from losses import DistillationLoss
from samplers import RASampler
import models
import sys
import attnweights_utils
import utils
from utils_pf import my_logger,my_meter,clamp,PCGrad

from models_svd.vision_transformer_svd import VisionTransformer_svd
from models_pf.DeiT import deit_base_patch16_224_d,deit_tiny_patch16_224_d

def get_args_parser():
    parser = argparse.ArgumentParser('DeiT training and evaluation script', add_help=False)
    parser.add_argument('--batch-size', default=32, type=int)
    parser.add_argument('--epochs', default=300, type=int)
    #patch_fool
    parser.add_argument('--name', default='', type=str)
    parser.add_argument('--dataset', default='ImageNet', type=str)
    parser.add_argument('--data_dir', default='D:/ViT/imagenet', type=str)
    parser.add_argument('--log_dir', default='log', type=str)
    parser.add_argument('--crop_size', default=224, type=int)
    parser.add_argument('--img_size', default=224, type=int)
    parser.add_argument('--workers', default=16, type=int)

    parser.add_argument('--network', default='DeiT-T', type=str, choices=['DeiT-B', 'DeiT-S', 'DeiT-T',
                                                                           'ResNet152', 'ResNet50', 'ResNet18'])
    parser.add_argument('--dataset_size', default=0.1, type=float, help='Use part of Eval set')

    parser.add_argument('--patch_select', default='Attn', type=str, choices=['Rand', 'Saliency', 'Attn'])
    parser.add_argument('--num_patch', default=2, type=int)
    parser.add_argument('--sparse_pixel_num', default=0, type=int)

    parser.add_argument('--attack_mode', default='Attention', choices=['CE_loss', 'Attention'], type=str)
    parser.add_argument('--atten_loss_weight', default=0.002, type=float)
    parser.add_argument('--atten_select', default=4, type=int, help='Select patch based on which attention layer')
    parser.add_argument('--mild_l_2', default=0., type=float, help='Range: 0-16')
    parser.add_argument('--mild_l_inf', default=0., type=float, help='Range: 0-1')

    parser.add_argument('--train_attack_iters', default=250, type=int)
    parser.add_argument('--random_sparse_pixel', action='store_true', help='random select sparse pixel or not')
    parser.add_argument('--learnable_mask_stop', default=200, type=int)

    parser.add_argument('--attack_learning_rate', default=0.22, type=float)
    parser.add_argument('--step_size', default=10, type=int)
    parser.add_argument('--gamma', default=0.95, type=float)

    parser.add_argument('--seedpf', default=0, type=int, help='Random seed')
    
    # Model parameters
    parser.add_argument('--model', default='deit_base_patch16_224', type=str, metavar='MODEL',
                        help='Name of model to train')
    parser.add_argument('--input-size', default=224, type=int, help='images input size')

    parser.add_argument('--drop', type=float, default=0.0, metavar='PCT',
                        help='Dropout rate (default: 0.)')
    parser.add_argument('--drop-path', type=float, default=0.1, metavar='PCT',
                        help='Drop path rate (default: 0.1)')

    parser.add_argument('--model-ema', action='store_true')
    parser.add_argument('--no-model-ema', action='store_false', dest='model_ema')
    parser.set_defaults(model_ema=True)
    parser.add_argument('--model-ema-decay', type=float, default=0.99996, help='')
    parser.add_argument('--model-ema-force-cpu', action='store_true', default=False, help='')

    # Optimizer parameters
    parser.add_argument('--opt', default='adamw', type=str, metavar='OPTIMIZER',
                        help='Optimizer (default: "adamw"')
    parser.add_argument('--opt-eps', default=1e-8, type=float, metavar='EPSILON',
                        help='Optimizer Epsilon (default: 1e-8)')
    parser.add_argument('--opt-betas', default=None, type=float, nargs='+', metavar='BETA',
                        help='Optimizer Betas (default: None, use opt default)')
    parser.add_argument('--clip-grad', type=float, default=None, metavar='NORM',
                        help='Clip gradient norm (default: None, no clipping)')
    parser.add_argument('--momentum', type=float, default=0.9, metavar='M',
                        help='SGD momentum (default: 0.9)')
    parser.add_argument('--weight-decay', type=float, default=0.05,
                        help='weight decay (default: 0.05)')
    # Learning rate schedule parameters
    parser.add_argument('--sched', default='cosine', type=str, metavar='SCHEDULER',
                        help='LR scheduler (default: "cosine"')
    parser.add_argument('--lr', type=float, default=5e-4, metavar='LR',
                        help='learning rate (default: 5e-4)')
    parser.add_argument('--lr-noise', type=float, nargs='+', default=None, metavar='pct, pct',
                        help='learning rate noise on/off epoch percentages')
    parser.add_argument('--lr-noise-pct', type=float, default=0.67, metavar='PERCENT',
                        help='learning rate noise limit percent (default: 0.67)')
    parser.add_argument('--lr-noise-std', type=float, default=1.0, metavar='STDDEV',
                        help='learning rate noise std-dev (default: 1.0)')
    parser.add_argument('--warmup-lr', type=float, default=1e-6, metavar='LR',
                        help='warmup learning rate (default: 1e-6)')
    parser.add_argument('--min-lr', type=float, default=1e-5, metavar='LR',
                        help='lower lr bound for cyclic schedulers that hit 0 (1e-5)')

    parser.add_argument('--decay-epochs', type=float, default=30, metavar='N',
                        help='epoch interval to decay LR')
    parser.add_argument('--warmup-epochs', type=int, default=5, metavar='N',
                        help='epochs to warmup LR, if scheduler supports')
    parser.add_argument('--cooldown-epochs', type=int, default=10, metavar='N',
                        help='epochs to cooldown LR at min_lr, after cyclic schedule ends')
    parser.add_argument('--patience-epochs', type=int, default=10, metavar='N',
                        help='patience epochs for Plateau LR scheduler (default: 10')
    parser.add_argument('--decay-rate', '--dr', type=float, default=0.1, metavar='RATE',
                        help='LR decay rate (default: 0.1)')

    # Augmentation parameters
    parser.add_argument('--color-jitter', type=float, default=0.4, metavar='PCT',
                        help='Color jitter factor (default: 0.4)')
    parser.add_argument('--aa', type=str, default='rand-m9-mstd0.5-inc1', metavar='NAME',
                        help='Use AutoAugment policy. "v0" or "original". " + \
                             "(default: rand-m9-mstd0.5-inc1)'),
    parser.add_argument('--smoothing', type=float, default=0.1, help='Label smoothing (default: 0.1)')
    parser.add_argument('--train-interpolation', type=str, default='bicubic',
                        help='Training interpolation (random, bilinear, bicubic default: "bicubic")')

    parser.add_argument('--repeated-aug', action='store_true')
    parser.add_argument('--no-repeated-aug', action='store_false', dest='repeated_aug')
    parser.set_defaults(repeated_aug=True)

    # * Random Erase params
    parser.add_argument('--reprob', type=float, default=0.25, metavar='PCT',
                        help='Random erase prob (default: 0.25)')
    parser.add_argument('--remode', type=str, default='pixel',
                        help='Random erase mode (default: "pixel")')
    parser.add_argument('--recount', type=int, default=1,
                        help='Random erase count (default: 1)')
    parser.add_argument('--resplit', action='store_true', default=False,
                        help='Do not random erase first (clean) augmentation split')

    # * Mixup params
    parser.add_argument('--mixup', type=float, default=0.8,
                        help='mixup alpha, mixup enabled if > 0. (default: 0.8)')
    parser.add_argument('--cutmix', type=float, default=1.0,
                        help='cutmix alpha, cutmix enabled if > 0. (default: 1.0)')
    parser.add_argument('--cutmix-minmax', type=float, nargs='+', default=None,
                        help='cutmix min/max ratio, overrides alpha and enables cutmix if set (default: None)')
    parser.add_argument('--mixup-prob', type=float, default=1.0,
                        help='Probability of performing mixup or cutmix when either/both is enabled')
    parser.add_argument('--mixup-switch-prob', type=float, default=0.5,
                        help='Probability of switching to cutmix when both mixup and cutmix enabled')
    parser.add_argument('--mixup-mode', type=str, default='batch',
                        help='How to apply mixup/cutmix params. Per "batch", "pair", or "elem"')

    # Distillation parameters
    parser.add_argument('--teacher-model', default='regnety_160', type=str, metavar='MODEL',
                        help='Name of teacher model to train (default: "regnety_160"')
    parser.add_argument('--teacher-path', type=str, default='')
    parser.add_argument('--distillation-type', default='none', choices=['none', 'soft', 'hard'], type=str, help="")
    parser.add_argument('--distillation-alpha', default=0.5, type=float, help="")
    parser.add_argument('--distillation-tau', default=1.0, type=float, help="")

    # * Finetuning params
    parser.add_argument('--finetune', default='', help='finetune from checkpoint')

    # Dataset parameters
    parser.add_argument('--data-path', default='/datasets01/imagenet_full_size/061417/', type=str,
                        help='dataset path')
    parser.add_argument('--data-set', default='IMNET', choices=['CIFAR', 'IMNET', 'INAT', 'INAT19'],
                        type=str, help='Image Net dataset path')
    parser.add_argument('--inat-category', default='name',
                        choices=['kingdom', 'phylum', 'class', 'order', 'supercategory', 'family', 'genus', 'name'],
                        type=str, help='semantic granularity')

    parser.add_argument('--output_dir', default='',
                        help='path where to save, empty for no saving')
    parser.add_argument('--device', default='cuda',
                        help='device to use for training / testing')
    parser.add_argument('--seed', default=0, type=int)
    parser.add_argument('--resume', default='', help='resume from checkpoint')
    parser.add_argument('--start_epoch', default=0, type=int, metavar='N',
                        help='start epoch')
    parser.add_argument('--eval', action='store_true', help='Perform evaluation only')
    parser.add_argument('--dist-eval', action='store_true', default=False, help='Enabling distributed evaluation')
    parser.add_argument('--num_workers', default=8, type=int)
    parser.add_argument('--pin-mem', action='store_true',
                        help='Pin CPU memory in DataLoader for more efficient (sometimes) transfer to GPU.')
    parser.add_argument('--no-pin-mem', action='store_false', dest='pin_mem',
                        help='')
    parser.set_defaults(pin_mem=True)

    # distributed training parameters
    parser.add_argument('--world_size', default=1, type=int,
                        help='number of distributed processes')
    parser.add_argument('--dist_url', default='env://', help='url used to set up distributed training')
    # save attn avg map
    parser.add_argument('--need_weight', action='store_true', help='Store attn map weights')
    # mask path
    parser.add_argument('--mask_path', default='')
    # svd type
    parser.add_argument('--svd_type', default=None, choices=[None, 'single_head', 'mix_head', 'mix_head_fc_k', 'mix_head_fc_qk', 'mix_head_fc_q'])
    # restart finetuning
    parser.add_argument('--restart_finetune', action='store_true', help='sparse finetuning after low rank approximation')
    return parser


def main(args):
    utils.init_distributed_mode(args)

    print(args)

    if args.distillation_type != 'none' and args.finetune and not args.eval:
        raise NotImplementedError("Finetuning with distillation not yet supported")

    device = torch.device(args.device)

    # fix the seed for reproducibility
    seed = args.seed + utils.get_rank()
    torch.manual_seed(seed)
    np.random.seed(seed)
    # random.seed(seed)

    cudnn.benchmark = True

    #dataset_train, args.nb_classes = build_dataset(is_train=True, args=args)
    args.nb_classes=1000
    dataset_val, _ = build_dataset(is_train=False, args=args)

    if True:  # args.distributed:
        num_tasks = utils.get_world_size()
        global_rank = utils.get_rank()
        
        '''
        if args.repeated_aug:
            sampler_train = RASampler(
                dataset_train, num_replicas=num_tasks, rank=global_rank, shuffle=True
            )
        else:
            sampler_train = torch.utils.data.DistributedSampler(
                dataset_train, num_replicas=num_tasks, rank=global_rank, shuffle=True
            )
            '''
        if args.dist_eval:
            if len(dataset_val) % num_tasks != 0:
                print('Warning: Enabling distributed evaluation with an eval dataset not divisible by process number. '
                      'This will slightly alter validation results as extra duplicate entries are added to achieve '
                      'equal num of samples per-process.')
            sampler_val = torch.utils.data.DistributedSampler(
                dataset_val, num_replicas=num_tasks, rank=global_rank, shuffle=False)
        else:
            sampler_val = torch.utils.data.SequentialSampler(dataset_val)
    else:
        sampler_train = torch.utils.data.RandomSampler(dataset_train)
        sampler_val = torch.utils.data.SequentialSampler(dataset_val)

    '''
    data_loader_train = torch.utils.data.DataLoader(
        dataset_train, sampler=sampler_train,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        pin_memory=args.pin_mem,
        drop_last=True,
    )
    '''

    data_loader_val = torch.utils.data.DataLoader(
        dataset_val, sampler=sampler_val,
        batch_size=int(1.5 * args.batch_size),
        num_workers=args.num_workers,
        pin_memory=args.pin_mem,
        drop_last=False
    )

    mixup_fn = None
    mixup_active = args.mixup > 0 or args.cutmix > 0. or args.cutmix_minmax is not None
    if mixup_active:
        mixup_fn = Mixup(
            mixup_alpha=args.mixup, cutmix_alpha=args.cutmix, cutmix_minmax=args.cutmix_minmax,
            prob=args.mixup_prob, switch_prob=args.mixup_switch_prob, mode=args.mixup_mode,
            label_smoothing=args.smoothing, num_classes=args.nb_classes)

    print(f"Creating model: {args.model}")
    # model = create_model(
    #     args.model,
    #     pretrained=False,
    #     num_classes=args.nb_classes,
    #     drop_rate=args.drop,
    #     drop_path_rate=args.drop_path,
    #     drop_block_rate=None,
    #     # need weight
    #     need_weight=args.need_weight,
    #     # mask
    #     mask_path=args.mask_path,
    #     # svd
    #     svd_type=args.svd_type,
    # )
    
    #---------------------------------------------#
    '''
    model = create_model(
        args.model,
        pretrained=False,
        num_classes=args.nb_classes,
        drop_rate=args.drop,
        drop_path_rate=args.drop_path,
        need_weight=args.need_weight,
        mask_path=args.mask_path,
        svd_type=args.svd_type,
        checkpoint_path='D:/ViT/deit_base-20250224T011019Z-001/deit_base/deit_base_info90/checkpoint_best.pth'
    )
    '''
    model = VisionTransformer_svd(
     patch_size=16, embed_dim=192, depth=12, num_heads=3, num_classes=args.nb_classes,drop_rate=args.drop,
    drop_path_rate=args.drop_path,need_weight=args.need_weight,mask_path=args.mask_path,svd_type=args.svd_type,)
    checkpoint = torch.load('D:/ViT/tiny_w/checkpoint_best.pth', map_location='cpu')
    model.load_state_dict(checkpoint['model'])
    model.to(device)
    
    model2 = deit_tiny_patch16_224_d(pretrained=True)
    model2 = model2.to(device)
    
    criterion = nn.CrossEntropyLoss().cuda()
    # eval dataset
    mu_ = [0.485, 0.456, 0.406]
    std_ = [0.229, 0.224, 0.225]
    mu = torch.tensor(mu_).view(3, 1, 1).cuda()
    std = torch.tensor(std_).view(3, 1, 1).cuda()
    
    patch_size = 16  
    
    logger = my_logger(args)  # 用于记录实验过程中的各种信息
    meter = my_meter()  # 用于记录实验过程中的各种信息

    start_time = time.time()

    '''Original image been classified incorrect but turn to be correct after adv attack'''
    false2true_num = 0
    for i, (X, y) in enumerate(data_loader_val):
        '''not using all of the eval dataset to get the final result'''
        if i == int(len(data_loader_val) * args.dataset_size):
            break

        X, y = X.cuda(), y.cuda()
        patch_num_per_line = int(X.size(-1) / patch_size)
        delta = torch.zeros_like(X).cuda()
        delta.requires_grad = True

        model2.zero_grad()
        out, atten = model2(X + delta)
        out1,attn1 = model(X+delta)
           # dimm=atten[11].shape
           # #64,3,197,197
        '''
            atten_layer_org=atten[11].mean(dim=1)[:,:,1:]
            with open('D:/ViT/Patch-Fool-main/Patch-Fool-main/output/{}/atten_index_org_dim_val.txt'.format(i), 'w') as f:
                print(atten_layer_org,file=f)
        '''

        classification_result = out.max(1)[1] == y
        correct_num = classification_result.sum().item()
        loss = criterion(out, y)
        meter.add_loss_acc("Base", {'CE': loss.item()}, correct_num, y.size(0))
        
        classification_result1 = out1.max(1)[1] == y
        correct_num1 = classification_result1.sum().item()
        loss1 = criterion(out1, y)
        meter.add_loss_acc("clean", {'CE': loss1.item()}, correct_num1, y.size(0))

        '''choose patch''' 
        # max_patch_index size: [Batch, num_patch attack]
        if args.patch_select == 'Rand':
            '''random choose patch'''
            max_patch_index = np.random.randint(0, 14 * 14, (X.size(0), args.num_patch))
            max_patch_index = torch.from_numpy(max_patch_index)
        elif args.patch_select == 'Saliency':
            '''gradient based method'''
            grad = torch.autograd.grad(loss, delta)[0]
            # print(grad.shape)
            grad = torch.abs(grad)
            patch_grad = F.conv2d(grad, filter, stride=patch_size)
            patch_grad = patch_grad.view(patch_grad.size(0), -1)
            max_patch_index = patch_grad.argsort(descending=True)[:, :args.num_patch]
        elif args.patch_select == 'Attn':
            '''attention based method'''
            atten_layer = atten[args.atten_select].mean(dim=1)
            if 'DeiT' in args.network:
                atten_layer = atten_layer.mean(dim=-2)[:, 1:]
            else:
                atten_layer = atten_layer.mean(dim=-2)[:, 1:]
            max_patch_index = atten_layer.argsort(descending=True)[:, :args.num_patch]
            #with open('D:/ViT/Patch-Fool-main/Patch-Fool-main/output/{}/chosen_patch.txt'.format(i), 'w') as f:
            #            print(max_patch_index,file=f)
        else:
            print(f'Unknown patch_select: {args.patch_select}')
            raise

        '''build mask'''
        mask = torch.zeros([X.size(0), 1, X.size(2), X.size(3)]).cuda()
        if args.sparse_pixel_num != 0:
            learnable_mask = mask.clone()

        for j in range(X.size(0)):
            index_list = max_patch_index[j]
            for index in index_list:
                row = (index // patch_num_per_line) * patch_size
                column = (index % patch_num_per_line) * patch_size

                if args.sparse_pixel_num != 0:
                    learnable_mask.data[j, :, row:row + patch_size, column:column + patch_size] = torch.rand(
                        [patch_size, patch_size])
                mask[j, :, row:row + patch_size, column:column + patch_size] = 1
        '''adv attack'''
        max_patch_index_matrix = max_patch_index[:, 0]
        max_patch_index_matrix = max_patch_index_matrix.repeat(197, 1)
        max_patch_index_matrix = max_patch_index_matrix.permute(1, 0)
        max_patch_index_matrix = max_patch_index_matrix.flatten().long()

        if args.mild_l_inf == 0:
            '''random init delta'''
            delta = (torch.rand_like(X) - mu) / std
        else:
            '''constrain delta: range [x-epsilon, x+epsilon]'''
            epsilon = args.mild_l_inf / std
            delta = 2 * epsilon * torch.rand_like(X) - epsilon + X

        delta.data = clamp(delta, (0 - mu) / std, (1 - mu) / std)
        original_img = X.clone()

        if args.random_sparse_pixel:
            '''random select pixels'''
            sparse_mask = torch.zeros_like(mask)
            learnable_mask_temp = learnable_mask.view(learnable_mask.size(0), -1)
            sparse_mask_temp = sparse_mask.view(sparse_mask.size(0), -1)
            value, _ = learnable_mask_temp.sort(descending=True)
            threshold = value[:, args.sparse_pixel_num - 1].view(-1, 1)
            sparse_mask_temp[learnable_mask_temp >= threshold] = 1
            mask = sparse_mask

        if args.sparse_pixel_num == 0 or args.random_sparse_pixel:
            X = torch.mul(X, 1 - mask)
        else:
            '''select by learnable mask'''
            learnable_mask.requires_grad = True
        delta = delta.cuda()
        delta.requires_grad = True

        opt = torch.optim.Adam([delta], lr=args.attack_learning_rate)
        if args.sparse_pixel_num != 0 and (not args.random_sparse_pixel):
            mask_opt = torch.optim.Adam([learnable_mask], lr=1e-2)
        scheduler = torch.optim.lr_scheduler.StepLR(opt, step_size=args.step_size, gamma=args.gamma)

        '''Start Adv Attack'''
        for train_iter_num in range(args.train_attack_iters):
            model2.zero_grad()
            opt.zero_grad()
            print("train iter:",train_iter_num)
            '''Build Sparse Patch attack binary mask'''
            if args.sparse_pixel_num != 0 and (not args.random_sparse_pixel):
                if train_iter_num < args.learnable_mask_stop:
                    mask_opt.zero_grad()
                    sparse_mask = torch.zeros_like(mask)
                    learnable_mask_temp = learnable_mask.view(learnable_mask.size(0), -1)
                    sparse_mask_temp = sparse_mask.view(sparse_mask.size(0), -1)
                    value, _ = learnable_mask_temp.sort(descending=True)

                    threshold = value[:, args.sparse_pixel_num-1].view(-1, 1)
                    sparse_mask_temp[learnable_mask_temp >= threshold] = 1

                    '''inference as sparse_mask but backward as learnable_mask'''
                    temp_mask = ((sparse_mask - learnable_mask).detach() + learnable_mask) * mask
                else:
                    temp_mask = sparse_mask

                X = original_img * (1-sparse_mask)
                if 'DeiT' in args.network:
                    out, atten = model2(X + torch.mul(delta, temp_mask))
                else:
                    out = model2(X + torch.mul(delta, temp_mask))

            else:
                if 'DeiT' in args.network:
                    out, atten = model2(X + torch.mul(delta, mask))
                else:
                    out = model2(X + torch.mul(delta, mask))

            '''final CE-loss'''
            loss = criterion(out, y)


            if args.attack_mode == 'Attention':
                grad = torch.autograd.grad(loss, delta, retain_graph=True)[0]#slow
                ce_loss_grad_temp = grad.view(X.size(0), -1).detach().clone()
                if args.sparse_pixel_num != 0 and (not args.random_sparse_pixel) and train_iter_num < args.learnable_mask_stop:
                    mask_grad = torch.autograd.grad(loss, learnable_mask, retain_graph=True)[0]

                # Attack the first 6 layers' Attn

                range_list = range(len(atten)//2)
                for atten_num in range_list:
                    if atten_num == 0:
                        continue
                    atten_map = atten[atten_num]
                    atten_map = atten_map.mean(dim=1)
                    atten_map = atten_map.view(-1, atten_map.size(-1))
                    atten_map = -torch.log(atten_map)
                    if 'DeiT' in args.network:
                        atten_loss = F.nll_loss(atten_map, max_patch_index_matrix + 1)
                    else:
                        atten_loss = F.nll_loss(atten_map, max_patch_index_matrix)

                    atten_grad = torch.autograd.grad(atten_loss, delta, retain_graph=True)[0]

                    atten_grad_temp = atten_grad.view(X.size(0), -1)
                    cos_sim = F.cosine_similarity(atten_grad_temp, ce_loss_grad_temp, dim=1)

                    if args.sparse_pixel_num != 0 and (not args.random_sparse_pixel) and train_iter_num < args.learnable_mask_stop:
                        mask_atten_grad = torch.autograd.grad(atten_loss, learnable_mask, retain_graph=True)[0]

                    '''PCGrad'''
                    #print("PGD start")
                    atten_grad = PCGrad(atten_grad_temp, ce_loss_grad_temp, cos_sim, grad.shape)
                    if args.sparse_pixel_num != 0 and (not args.random_sparse_pixel):
                        mask_atten_grad_temp = mask_atten_grad.view(mask_atten_grad.size(0), -1)
                        ce_mask_grad_temp = mask_grad.view(mask_grad.size(0), -1)
                        mask_cos_sim = F.cosine_similarity(mask_atten_grad_temp, ce_mask_grad_temp, dim=1)
                        mask_atten_grad = PCGrad(mask_atten_grad_temp, ce_mask_grad_temp, mask_cos_sim, mask_atten_grad.shape)

                    grad += atten_grad * args.atten_loss_weight
                    if args.sparse_pixel_num != 0 and (not args.random_sparse_pixel):
                        mask_grad += mask_atten_grad * args.atten_loss_weight
                    #print("PGD end")
            else:
                '''no attention loss'''
                if args.sparse_pixel_num != 0 and (not args.random_sparse_pixel) and train_iter_num < args.learnable_mask_stop:
                    grad = torch.autograd.grad(loss, delta, retain_graph=True)[0]
                    mask_grad = torch.autograd.grad(loss, learnable_mask)[0]
                else:
                    grad = torch.autograd.grad(loss, delta)[0]

            opt.zero_grad()
            delta.grad = -grad
            opt.step()
            scheduler.step()

            if args.sparse_pixel_num != 0 and (not args.random_sparse_pixel) and train_iter_num < args.learnable_mask_stop:
                mask_opt.zero_grad()
                learnable_mask.grad = -mask_grad
                mask_opt.step()

                #batchsize,channels,x,y
                #X.size(0)->batchsize
                learnable_mask_temp = learnable_mask.view(X.size(0), -1)
                learnable_mask.data -= learnable_mask_temp.min(-1)[0].view(-1, 1, 1, 1)
                learnable_mask.data += 1e-6
                learnable_mask.data *= mask

            '''l2 constrain'''
            if args.mild_l_2 != 0:
                radius = (args.mild_l_2 / std).squeeze()
                perturbation = (delta.detach() - original_img) * mask
                l2 = torch.linalg.norm(perturbation.view(perturbation.size(0), perturbation.size(1), -1), dim=-1)
                radius = radius.repeat([l2.size(0), 1])
                l2_constraint = radius / l2
                l2_constraint[l2 < radius] = 1.
                l2_constraint = l2_constraint.view(l2_constraint.size(0), l2_constraint.size(1), 1, 1)
                delta.data = original_img + perturbation * l2_constraint

            '''l_inf constrain'''
            if args.mild_l_inf != 0:
                epsilon = args.mild_l_inf / std
                delta.data = clamp(delta, original_img - epsilon, original_img + epsilon)

            delta.data = clamp(delta, (0 - mu) / std, (1 - mu) / std)
        
        '''Eval Adv Attack'''
        with torch.no_grad():
            if args.sparse_pixel_num == 0 or args.random_sparse_pixel:
                perturb_x = X + torch.mul(delta, mask)
                if 'DeiT' in args.network:
                    out, atten = model(perturb_x)
                    #atten_layer_adv=atten[11].mean(dim=1)[:,:,1:]
                    #with open('D:/ViT/Patch-Fool-main/Patch-Fool-main/output/{}/atten_index_adv_dim_val.txt'.format(i), 'w') as f:
                    #    print(atten_layer_adv,file=f)
                    '''
                    atten_layer_adv=atten[11].mean(dim=1)
                    atten_layer_adv=atten_layer_adv.mean(dim=-2)[:,1:]
                    with open('D:/ViT/Patch-Fool-main/Patch-Fool-main/output/{}/atten_index_adv_val.txt'.format(i), 'w') as f:
                        print(atten_layer_adv,file=f)
                    '''
                    '''
                    atten_layer_adv=atten[11].mean(dim=1)[:,:,1:]
                    max_patch_index_last = atten_layer_adv.argsort(descending=True)[:, :,:1]
                    with open('D:/ViT/Patch-Fool-main/Patch-Fool-main/output/{}/atten_index_dim4.txt'.format(i), 'w') as f:
                        print(max_patch_index_last,file=f)
                    '''
                else:
                    out,atten = model(perturb_x)
                #for j in range(perturb_x.size(0)):
                #    conver2pic(perturb_x[j],i,j)
                #dimension of atten is 4
                #dimension1 12->different attention layer
                #dimension2 64->different picture(batch size)
                #dimension3 3->different channel
                #dimension4 197->different token
                '''
                atten_layer_num = len(atten)
                num1=len(atten[0])
                num2=len(atten[0][0])
                num3=len(atten[0][0][0])
                atten_map_last = atten[atten_layer_num-1]
                atten_map_last_sing=atten_map_last[0][0]
                #print(atten_map_last_sing)
               # with open('D:/ViT/Patch-Fool-main/Patch-Fool-main/output/{}/atten.txt'.format(i), 'w') as f:
                #    print(atten_map_last_sing,file=f)
                visualize_attention_map(atten1,atten2,X,perturb_x,out1,out2,max_patch_index)
                '''

                
            else:
                if train_iter_num < args.learnable_mask_stop:
                    sparse_mask = torch.zeros_like(mask)
                    learnable_mask_temp = learnable_mask.view(learnable_mask.size(0), -1)
                    temp_mask = sparse_mask.view(sparse_mask.size(0), -1)
                    value, _ = learnable_mask_temp.sort(descending=True)
                    threshold = value[:, args.sparse_pixel_num - 1].view(-1, 1)
                    temp_mask[learnable_mask_temp >= threshold] = 1

                print((sparse_mask * mask).view(mask.size(0), -1).sum(-1))
                print("xxxxxxxxxxxxxxxxxxxxxx")
                X = original_img * (1 - sparse_mask)
                perturb_x = X + torch.mul(delta, sparse_mask)
                if 'DeiT' in args.network:
                    out, atten = model(perturb_x)
                else:
                    out = model(perturb_x)
                
                
                
            

            classification_result_after_attack = out.max(1)[1] == y
            loss = criterion(out, y)
            meter.add_loss_acc("ADV", {'CE': loss.item()}, (classification_result_after_attack.sum().item()), y.size(0))

        '''Message'''
        if i % 1 == 0:
            logger.info("Iter: [{:d}/{:d}] Loss and Acc for all models:".format(i, int(len(data_loader_val) * args.dataset_size)))
            msg = meter.get_loss_acc_msg()
            logger.info(msg)

            with open('log/cln_adv_small_3'.format(i), 'a') as f:
                print(msg,file=f)

            classification_result_after_attack = classification_result_after_attack[classification_result == False]
            false2true_num += classification_result_after_attack.sum().item()
            logger.info("Total False -> True: {}".format(false2true_num))

    end_time = time.time()
    msg = meter.get_loss_acc_msg()
    logger.info("\nFinish! Using time: {}\n{}".format((end_time - start_time), msg))
    return

    #---------------------------------------------#


    if (args.model == 'vit_base_patch16_224'):
        #model = create_model("vit_base_patch16_224", pretrained=False)
        model = VisionTransformer_svd(
        patch_size=16, embed_dim=768, depth=12, num_heads=12,num_classes=args.nb_classes,drop_rate=args.drop,
        drop_path_rate=args.drop_path,need_weight=args.need_weight,mask_path=args.mask_path,svd_type=args.svd_type,)

    elif args.model == 'vit_tiny_patch16_224':
        model = VisionTransformer_svd(
        patch_size=16, embed_dim=192, depth=12, num_heads=3,num_classes=args.nb_classes,drop_rate=args.drop,
        drop_path_rate=args.drop_path,need_weight=args.need_weight,mask_path=args.mask_path,svd_type=args.svd_type,)

    if args.finetune:
        if args.finetune.startswith('https'):
            checkpoint = torch.hub.load_state_dict_from_url(
                args.finetune, map_location='cpu', check_hash=True)
        else:
            checkpoint = torch.load(args.finetune, map_location='cpu')
        if (args.model == 'vit_base_patch16_224'):
            checkpoint_model = checkpoint
        else:
            checkpoint_model = checkpoint['model']
        state_dict = model.state_dict()
        for k in ['head.weight', 'head.bias', 'head_dist.weight', 'head_dist.bias']:
            if k in checkpoint_model and checkpoint_model[k].shape != state_dict[k].shape:
                print(f"Removing key {k} from pretrained checkpoint")
                del checkpoint_model[k]

        # interpolate position embedding
        '''
        pos_embed_checkpoint = checkpoint_model['pos_embed']
        embedding_size = pos_embed_checkpoint.shape[-1]
        num_patches = model.patch_embed.num_patches
        num_extra_tokens = model.pos_embed.shape[-2] - num_patches
        # height (== width) for the checkpoint position embedding
        orig_size = int((pos_embed_checkpoint.shape[-2] - num_extra_tokens) ** 0.5)
        # height (== width) for the new position embedding
        new_size = int(num_patches ** 0.5)
        # class_token and dist_token are kept unchanged
        extra_tokens = pos_embed_checkpoint[:, :num_extra_tokens]
        # only the position tokens are interpolated
        pos_tokens = pos_embed_checkpoint[:, num_extra_tokens:]
        pos_tokens = pos_tokens.reshape(-1, orig_size, orig_size, embedding_size).permute(0, 3, 1, 2)
        pos_tokens = torch.nn.functional.interpolate(
            pos_tokens, size=(new_size, new_size), mode='bicubic', align_corners=False)
        pos_tokens = pos_tokens.permute(0, 2, 3, 1).flatten(1, 2)
        new_pos_embed = torch.cat((extra_tokens, pos_tokens), dim=1)
        checkpoint_model['pos_embed'] = new_pos_embed
        '''

        model.load_state_dict(checkpoint_model, strict=False)

    model.to(device)

    model_ema = None
    if args.model_ema:
        # Important to create EMA model after cuda(), DP wrapper, and AMP but before SyncBN and DDP wrapper
        model_ema = ModelEma(
            model,
            decay=args.model_ema_decay,
            device='cpu' if args.model_ema_force_cpu else '',
            resume='')

    model_without_ddp = model
    if args.distributed:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.gpu])
        model_without_ddp = model.module
    n_parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print('number of params:', n_parameters)

    linear_scaled_lr = args.lr * args.batch_size * utils.get_world_size() / 512.0
    args.lr = linear_scaled_lr
    optimizer = create_optimizer(args, model_without_ddp)
    loss_scaler = NativeScaler()

    lr_scheduler, _ = create_scheduler(args, optimizer)

    criterion = LabelSmoothingCrossEntropy()

    if mixup_active:
        # smoothing is handled with mixup label transform
        criterion = SoftTargetCrossEntropy()
    elif args.smoothing:
        criterion = LabelSmoothingCrossEntropy(smoothing=args.smoothing)
    else:
        criterion = torch.nn.CrossEntropyLoss()

    teacher_model = None
    if args.distillation_type != 'none':
        assert args.teacher_path, 'need to specify teacher-path when using distillation'
        print(f"Creating teacher model: {args.teacher_model}")
        teacher_model = create_model(
            args.teacher_model,
            pretrained=False,
            num_classes=args.nb_classes,
            global_pool='avg',
        )
        if args.teacher_path.startswith('https'):
            checkpoint = torch.hub.load_state_dict_from_url(
                args.teacher_path, map_location='cpu', check_hash=True)
        else:
            checkpoint = torch.load(args.teacher_path, map_location='cpu')
        teacher_model.load_state_dict(checkpoint['model'])
        teacher_model.to(device)
        teacher_model.eval()

    # wrap the criterion in our custom DistillationLoss, which
    # just dispatches to the original criterion if args.distillation_type is 'none'
    criterion = DistillationLoss(
        criterion, teacher_model, args.distillation_type, args.distillation_alpha, args.distillation_tau
    )

    output_dir = Path(args.output_dir)

    if args.resume:
        if args.resume.startswith('https'):
            checkpoint = torch.hub.load_state_dict_from_url(
                args.resume, map_location='cpu', check_hash=True)
        else:
            checkpoint = torch.load(args.resume, map_location='cpu')
        strict = False if args.need_weight else True
        if (args.model == 'vit_base_patch16_224'):
            model_without_ddp.load_state_dict(checkpoint, strict=strict)
        else:
            if args.svd_type is not None and 'mix_head_fc' in args.svd_type:
                model_dict = model_without_ddp.state_dict()
                model_dict.update(checkpoint['model'])
                model_without_ddp.load_state_dict(model_dict)

                # n_parameters = sum(p.numel() for p in model_without_ddp.parameters() if p.requires_grad)
                # print('unfreezed params: {}'.format(n_parameters))

                # for name, param in model_without_ddp.named_parameters():
                #     if 'encoder' not in name and 'decoder' not in name:
                #         param.requires_grad = False

                # n_parameters = sum(p.numel() for p in model_without_ddp.parameters() if p.requires_grad)
                # print('unfreezed params: {}'.format(n_parameters))

            else:
                model_without_ddp.load_state_dict(checkpoint['model'], strict=strict)
        if not args.eval and 'optimizer' in checkpoint and 'lr_scheduler' in checkpoint and 'epoch' in checkpoint and not args.restart_finetune:
            optimizer.load_state_dict(checkpoint['optimizer'])
            lr_scheduler.load_state_dict(checkpoint['lr_scheduler'])
            args.start_epoch = checkpoint['epoch'] + 1
            if args.model_ema:
                utils._load_checkpoint_for_ema(model_ema, checkpoint['model_ema'])
            if 'scaler' in checkpoint:
                loss_scaler.load_state_dict(checkpoint['scaler'])

    if args.eval:
        if args.need_weight:
            attnweights_utils.init(model, args)
            test_stats = evaluate(data_loader_train, model, device, svd_type=args.svd_type)
            attnweights_utils.save(model, args)
            print(f"Accuracy of the network on the {len(dataset_val)} train images: {test_stats['acc1']:.1f}%")
        else:
            test_stats = evaluate(data_loader_val, model, device, svd_type=args.svd_type)
            print(f"Accuracy of the network on the {len(dataset_val)} test images: {test_stats['acc1']:.1f}%")
        return

    print(f"Start training for {args.epochs} epochs")
    start_time = time.time()
    max_accuracy = 0.0
    for epoch in range(args.start_epoch, args.epochs):
        if args.distributed:
            data_loader_train.sampler.set_epoch(epoch)

        train_stats = train_one_epoch(
            model, criterion, data_loader_train,
            optimizer, device, epoch, loss_scaler,
            args.clip_grad, model_ema, mixup_fn,
            set_training_mode=args.finetune == '',  # keep in eval mode during finetuning
            svd_type=args.svd_type,
            output_dir=args.output_dir,
        )

        lr_scheduler.step(epoch)
        if args.output_dir:
            checkpoint_paths = [output_dir / 'checkpoint.pth']
            for checkpoint_path in checkpoint_paths:
                utils.save_on_master({
                    'model': model_without_ddp.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'lr_scheduler': lr_scheduler.state_dict(),
                    'epoch': epoch,
                    'model_ema': get_state_dict(model_ema),
                    'scaler': loss_scaler.state_dict(),
                    'args': args,
                }, checkpoint_path)

        test_stats = evaluate(data_loader_val, model, device, svd_type=args.svd_type)
        print(f"Accuracy of the network on the {len(dataset_val)} test images: {test_stats['acc1']:.1f}%")

        # save checkpoints that have best accuracy
        if test_stats['acc1'] >= max_accuracy:
            if args.output_dir:
                # checkpoint_paths = [output_dir / 'checkpoint_best_{}.pth'.format(str(test_stats['acc1']))]
                checkpoint_paths = [output_dir / 'checkpoint_best.pth']
                for checkpoint_path in checkpoint_paths:
                    utils.save_on_master({
                        'model': model_without_ddp.state_dict(),
                        'optimizer': optimizer.state_dict(),
                        'lr_scheduler': lr_scheduler.state_dict(),
                        'epoch': epoch,
                        'model_ema': get_state_dict(model_ema),
                        'scaler': loss_scaler.state_dict(),
                        'args': args,
                    }, checkpoint_path)

        max_accuracy = max(max_accuracy, test_stats["acc1"])
        print(f'Max accuracy: {max_accuracy:.2f}%')

        log_stats = {**{f'train_{k}': v for k, v in train_stats.items()},
                     **{f'test_{k}': v for k, v in test_stats.items()},
                     'epoch': epoch,
                     'n_parameters': n_parameters}

        if args.output_dir and (epoch % 500 == 0) and utils.is_main_process():
            with (output_dir / "log.txt").open("a") as f:
                f.write(json.dumps(log_stats) + "\n")

    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print('Training time {}'.format(total_time_str))


if __name__ == '__main__':
    parser = argparse.ArgumentParser('DeiT training and evaluation script', parents=[get_args_parser()])
    args = parser.parse_args()
    if args.output_dir:
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    main(args)
